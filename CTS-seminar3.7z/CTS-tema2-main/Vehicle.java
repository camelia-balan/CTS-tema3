package ro.ase.cts.s02.src;

public class Vehicle {
    double value;

    public double getValue() {
        return value;
    }
    public double calculateValue() {
        return value;
    }
}
