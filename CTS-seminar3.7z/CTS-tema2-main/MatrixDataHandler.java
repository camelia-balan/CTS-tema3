package ro.ase.cts.s02.src;

import java.io.*;

//de modificat:
//tratare caz in care a fost modificat fisierul
//separare in diferite metode: citire matrice din fisier, scriere matrice in fisier
//tratare exceptii

public class MatrixDataHandler {
    private int[][] matrix;
    private int height;
    private int width;
    private String filename;

    /**
     * Citeste din fisier datele pentru o matrice conform clasei curente.
     * @return true daca s-a citit cu succes si false daca a aparut exceptie
     */
    public boolean readMatrixFromFile() {
            try {
                BufferedReader bufferedReader = new BufferedReader(new FileReader(this.filename));
                String line = bufferedReader.readLine();
                height = Integer.parseInt(line.split(" ")[0]);
                width = Integer.parseInt(line.split(" ")[1]);

                for (int i = 0; i < height; i++) {
                    line = bufferedReader.readLine();
                    for (int j = 0; j < width; j++) {
                        matrix[i][j] = Integer.parseInt(line.split(" ")[j]);
                    }
                }
                bufferedReader.close();
                return true;
            } catch (IOException exception) {
                System.out.println(exception.getMessage());
                return false;
            }
    }

    /**
     * Metoda scrie matricea in fisierul denumit <this.filename>
     * @return Se returneaza true daca scrierea s-a facut cu succes si false in caz contrar.
     */
    public boolean writeMatrixInFile() {
        try {
            FileWriter fw = new FileWriter(this.filename);
            fw.write(height + " " + width + "\n");
            for (int i = 0; i < height; i++) {
                for (int j = 0; j < width; j++) {
                    fw.write(matrix[i][j] + " ");
                }
                fw.write("\n");
            }
            fw.close();
            return true;
        } catch (IOException exception) {
            System.out.println(exception.getMessage());
            // System.exit(-1); => daca voiam sa se inchida aplicatia
            return false;
        }
    }

    /**
    * Constructorul care initializeaza matricea pe baza valorilor primite pentru dimensiuni.
    * Apoi, matricea initializata este scrisa in fisierul filename.
    * @param height
    * @param width
    * @param filename
    */
    public MatrixDataHandler(int height, int width, String filename) {
        this.height = height;
        this.width = width;
        this.filename = filename;
        matrix = new int[height][];
        for (int i = 0; i < height; i++) {
            matrix[i] = new int[width];
        }
        if(!this.writeMatrixInFile())
            System.out.println("Ceva nu a fost ok la scrierea in fisier");
    }

    /**
     * Returneaza valoarea de pe o anumita pozitie in matrice.
     * Inainte de a returna se va actualiza matricea cu datele din fisier.
     * @param posHeight Linia de pe care se citeste.
     * @param posWidth Coloana de pe care se citeste.
     * @return Valoarea de pe pozitie.
     */
    public int getValueFromPosition(int posHeight, int posWidth) {
        if(!this.readMatrixFromFile())
            System.out.println("Citirea din fisier a esuat. Datele returnate sunt cele existente in <matrix> local.");
        return this.matrix[posHeight][posWidth];
    }

    /**
     * Se citesc valorile din fisier, se modifica valoarea dorita si apoi se rescriu datele in fisier.
     * @param posHeight Linia pe care se scrie.
     * @param posWidth Coloana pe care se scrie
     * @param val Noua valoare.
     */
    public void modifyValueAndUpdateFile(int posHeight, int posWidth, int val) {
        this.readMatrixFromFile();
        this.matrix[posHeight][posWidth]=val;
        this.writeMatrixInFile();
    }
}
